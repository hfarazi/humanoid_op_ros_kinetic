Changelog
=========

1.1.0
-----

- 1.0.4 `96b6f19ae <https://github.com/ralphbean/ansi2html/commit/96b6f19ae99a239051cd52c8edd7980d791736e9>`_
- 1.0.4 `b7e6e048c <https://github.com/ralphbean/ansi2html/commit/b7e6e048cc78324849c2af93d4948f6bc696ff09>`_
- 1.0.5 `f9cab7af7 <https://github.com/ralphbean/ansi2html/commit/f9cab7af7483969d73e3696e988945cc797e5149>`_
- 1.0.9 `1594cddb7 <https://github.com/ralphbean/ansi2html/commit/1594cddb714890ee7878150da679c89373f8846b>`_

1.0.8
-----

- added  setup.cfg file `547bd1cb5 <https://github.com/ralphbean/ansi2html/commit/547bd1cb5e5e65ab674d3cd489af872213f60051>`_
- Merge branch 'develop' of github.com:ralphbean/ansi2html into develop `352d14be6 <https://github.com/ralphbean/ansi2html/commit/352d14be694c0bfb10119c00639f319697587c26>`_
- changed setup.cfg to work on python 2.6.6 `7a12a92ed <https://github.com/ralphbean/ansi2html/commit/7a12a92edf1747e64b28cb41c7e0f11787d7774e>`_
- actually, python 2.6.6 on RH, centos etc has OrderedDict `512377d63 <https://github.com/ralphbean/ansi2html/commit/512377d63f7ecfb583530121330d9a0552a24e78>`_
- Merge pull request #55 from JensTimmerman/develop `03c3e680c <https://github.com/ralphbean/ansi2html/commit/03c3e680c90ca77c24ee465213a88f3726caf5bf>`_
- Prevent IndexError while handling CursorMoveUp `7a91200df <https://github.com/ralphbean/ansi2html/commit/7a91200df0d6f088b0ba947420d8829bf04caecd>`_
- Merge pull request #56 from lqez/fix/over-cursormoveup `a23772b57 <https://github.com/ralphbean/ansi2html/commit/a23772b57d584676792cbcdb74266c361a831f61>`_
- style: Include all 16 solarized colors in the scheme `081c9a741 <https://github.com/ralphbean/ansi2html/commit/081c9a741d1b0f09d8ab9c66dc9647bb882142c2>`_
- style: Encode pallete in 256 color encoding `acaa92ff2 <https://github.com/ralphbean/ansi2html/commit/acaa92ff2370d7ebda85ee68a47bfdb7d309a811>`_
- Merge pull request #57 from tbabej/develop `e1bd92d3e <https://github.com/ralphbean/ansi2html/commit/e1bd92d3e735d5143a81836ca6eb5e6d597bd987>`_
- Update travis config. `74c4f1dc8 <https://github.com/ralphbean/ansi2html/commit/74c4f1dc8b6c3ca41dd9dee284922c88f5934d10>`_
- Fix existing test suite. `eb7798cb7 <https://github.com/ralphbean/ansi2html/commit/eb7798cb7704465f242e97149d7483074f4d6226>`_
- Fill out color palettes that were under-specified. `5e55018eb <https://github.com/ralphbean/ansi2html/commit/5e55018eb331e2d934215821e874e30eab20e6ef>`_
- Merge branch 'feature/fixes' into develop `100be7c2d <https://github.com/ralphbean/ansi2html/commit/100be7c2d83d40d10b161d3def9b8e2b56e49b32>`_
- Fix line height stuff. `db1ee5b47 <https://github.com/ralphbean/ansi2html/commit/db1ee5b47c0495ebb6bffb39c17891fe25dcd8d7>`_
- Fix tests for the new palette values. `e8c6b9362 <https://github.com/ralphbean/ansi2html/commit/e8c6b9362287033c6d9296d61f8940aaae8703a4>`_

1.0.7
-----

- Implemented LaTeX support. Only colors are supported but it does already what I need. `caa8c6fe5 <https://github.com/ralphbean/ansi2html/commit/caa8c6fe5010c3d912aac47ce1e6e3aeaddfaa17>`_
- Updated README.rst. `4979c1409 <https://github.com/ralphbean/ansi2html/commit/4979c14091e43ee1090dc2399e04f57e8d60db95>`_
- Added first test for LaTeX output. `4b80d41e0 <https://github.com/ralphbean/ansi2html/commit/4b80d41e0bd1f7bc4dd73df82cc67acb6917d4e9>`_
- Added title and linkify for LaTeX. `3a869bce1 <https://github.com/ralphbean/ansi2html/commit/3a869bce19a6ad0c219d1c5f524e9c7b9784f978>`_
- Trying to fix https://travis-ci.org/ralphbean/ansi2html/jobs/25808505. `a0a06b41c <https://github.com/ralphbean/ansi2html/commit/a0a06b41cc7fe10e5241954fc03438c41a16a338>`_
- Fixed unicode escape problem. Fixes https://travis-ci.org/ralphbean/ansi2html/builds/26243970. `095eca5a5 <https://github.com/ralphbean/ansi2html/commit/095eca5a5731ce45a1a4cbf77e3cdfdf2e6716cb>`_
- Sure % has a special meaning … `2324a3dcf <https://github.com/ralphbean/ansi2html/commit/2324a3dcfe5b9896d0e93aec4b9de4202894eb73>`_
- Merge pull request #48 from ypid/ansi2latex `91e174cfd <https://github.com/ralphbean/ansi2html/commit/91e174cfd207c2fa273153ba11275459c3a5a1a2>`_
- set pre's id to "content" `6f14bc202 <https://github.com/ralphbean/ansi2html/commit/6f14bc202afa20379cdc3b5c15819119ea8b524f>`_
- the css `418bef2f0 <https://github.com/ralphbean/ansi2html/commit/418bef2f03dd36e7ad0dac663db0e917879d3dee>`_
- Merge pull request #50 from szepeviktor/patch-2 `97977e53b <https://github.com/ralphbean/ansi2html/commit/97977e53b4c85738be603c7f236958f95aacf1f9>`_
- Merge pull request #52 from szepeviktor/patch-3 `620fc1032 <https://github.com/ralphbean/ansi2html/commit/620fc1032af177406b17facfa20093b85772a2c5>`_
- Use the data_files that we build above. `654bc30b4 <https://github.com/ralphbean/ansi2html/commit/654bc30b40d89acdec91a194ff8651a6db86f812>`_

1.0.6
-----

- 1.0.4 `b7e6e048c <https://github.com/ralphbean/ansi2html/commit/b7e6e048cc78324849c2af93d4948f6bc696ff09>`_
- 1.0.5 `f9cab7af7 <https://github.com/ralphbean/ansi2html/commit/f9cab7af7483969d73e3696e988945cc797e5149>`_
- use optparse choices to deal with invalid scheme selection. `214d73609 <https://github.com/ralphbean/ansi2html/commit/214d73609ff0e0dd645778dbbc0392cd340f8df5>`_
- added solarized and os X terminal color schemes `2176bc4d0 <https://github.com/ralphbean/ansi2html/commit/2176bc4d050f52b69dd9227e29508a9dfd2e1b0a>`_
- Merge pull request #41 from schettino72/more-schemes `609326371 <https://github.com/ralphbean/ansi2html/commit/609326371e74c8f19c4185f76a64e24f54d6cfbf>`_
- Revert "Conditionally install man page into system or virtualenv.  For #39." `c1ee2bac9 <https://github.com/ralphbean/ansi2html/commit/c1ee2bac9bf66944cce387a4f1a534a408966d6a>`_
- Install man page to ${PREFIX}, not /usr (issue #39) `86abc9e3d <https://github.com/ralphbean/ansi2html/commit/86abc9e3dd8769af848a93ac2afc3728688554b3>`_
- Merge pull request #42 from hartwork/issue-39 `e81c55b38 <https://github.com/ralphbean/ansi2html/commit/e81c55b38b3368ceb05842823f980320607ed6db>`_
- add empty title element to head section in html output `c16fe680b <https://github.com/ralphbean/ansi2html/commit/c16fe680b18fa5c880ae8ed71fab3b062c2a371a>`_
- Merge pull request #43 from CBke/develop `c13f4a985 <https://github.com/ralphbean/ansi2html/commit/c13f4a9852785fc4c68d416747923b2f6653faca>`_
- 1.0.4 `40526f43a <https://github.com/ralphbean/ansi2html/commit/40526f43a009c85fddc0ab34de51e9eb94883e1c>`_
- 1.0.5 `e6a150e9d <https://github.com/ralphbean/ansi2html/commit/e6a150e9dd00f607ad32377878e36e2783cba784>`_
- Fix tests for added title. `aab8348ce <https://github.com/ralphbean/ansi2html/commit/aab8348ced14e747178772b49e0a796effeec974>`_
- add option --title for filling in the title `007e77c50 <https://github.com/ralphbean/ansi2html/commit/007e77c507cd9bc8465caa46fc47abbd66d5c313>`_
- Merge pull request #44 from CBke/develop `4fd918e54 <https://github.com/ralphbean/ansi2html/commit/4fd918e54e62d2658f3fdedc5347070de96ddcff>`_
- Drop manpage installation stuff. `a2f157614 <https://github.com/ralphbean/ansi2html/commit/a2f157614243e70d0134818ef1c37b1b780339d5>`_

1.0.5
-----

- added support to select a color-scheme. added schemes 'xterm' and 'xterm-bright' `367289a86 <https://github.com/ralphbean/ansi2html/commit/367289a86bb81f0c22801b6db7b63cc8acdec300>`_
- Merge pull request #40 from schettino72/color-schemes `1111aec78 <https://github.com/ralphbean/ansi2html/commit/1111aec7863584c1153438e89833f53be29fa249>`_
- 1.0.4 `96b6f19ae <https://github.com/ralphbean/ansi2html/commit/96b6f19ae99a239051cd52c8edd7980d791736e9>`_
- 1.0.4 `b7e6e048c <https://github.com/ralphbean/ansi2html/commit/b7e6e048cc78324849c2af93d4948f6bc696ff09>`_

1.0.4
-----


1.0.3
-----

- Makefile: Fix regression where version bumps would not force a rebuild of the man page `750fe09fe <https://github.com/ralphbean/ansi2html/commit/750fe09feccf600ee19d5842649a9b9cd6965510>`_
- Makefile: Mark target upload as phony `ac3877f57 <https://github.com/ralphbean/ansi2html/commit/ac3877f5728281ed2df792767ad18e6283001615>`_
- Merge pull request #38 from hartwork/dependency-regression `10b6051a4 <https://github.com/ralphbean/ansi2html/commit/10b6051a4bd207064a77b5f28be7e6954c028d8b>`_
- Conditionally install man page into system or virtualenv.  For #39. `720ac2f93 <https://github.com/ralphbean/ansi2html/commit/720ac2f93e6dfb1c77520dc5f7aeab4f031dfd75>`_

1.0.2
-----

- Add an upload command to the Makefile. `12e68427c <https://github.com/ralphbean/ansi2html/commit/12e68427c8dc4255bb4da8ccd8024c2b742be8e8>`_
- Tweak travis setup. `07a95ef6e <https://github.com/ralphbean/ansi2html/commit/07a95ef6e5d0c6afc5ee53fa5ce6f9c5bc3a2bab>`_
- Remove a forgotten import. `756139724 <https://github.com/ralphbean/ansi2html/commit/75613972499b6ee18326bdd2989e5411ad475ce9>`_

1.0.1
-----

- Change the way we store version info. `4e4eaef33 <https://github.com/ralphbean/ansi2html/commit/4e4eaef33d27aea931b57c3eee61ec16cc47cf87>`_

1.0.0
-----

- Add trove for py3.3. `683f672fa <https://github.com/ralphbean/ansi2html/commit/683f672fa6071cc7390b6c64858127fe0b1e2e77>`_
- Stop adding unwanted spaces (issue 26) `b5163a80f <https://github.com/ralphbean/ansi2html/commit/b5163a80feea7f6ba8879357524ccbe143e68281>`_
- Add test for issue 25 `6df79eb8b <https://github.com/ralphbean/ansi2html/commit/6df79eb8b95b2c36e7395bedcd13e0facb323434>`_
- Fix destructive reset marker handling (issue 25) `4db97b126 <https://github.com/ralphbean/ansi2html/commit/4db97b126c600d30a922ab5899faa8879f699739>`_
- Fix ANSI code decoding (issue 25) `f277f8f3c <https://github.com/ralphbean/ansi2html/commit/f277f8f3c4eaa1256c5df66238583b5a69882456>`_
- Fix writing to sys.stdout.buffer `7a3267d53 <https://github.com/ralphbean/ansi2html/commit/7a3267d53a2ea61a0af6021faedf154ba89b2f87>`_
- Add convenience Makefile `8d3f3e055 <https://github.com/ralphbean/ansi2html/commit/8d3f3e055e679bf723d6a846fbff2c95a7224b9a>`_
- Merge pull request #30 from hartwork/makefile `156bc89da <https://github.com/ralphbean/ansi2html/commit/156bc89da97c7de19b2beb8e2de7bde2f2535a20>`_
- Merge pull request #29 from hartwork/issue_29 `8495723ae <https://github.com/ralphbean/ansi2html/commit/8495723ae8e057248537a53f9e7e800547d6640e>`_
- Merge pull request #27 from hartwork/issue_26 `74d237c18 <https://github.com/ralphbean/ansi2html/commit/74d237c18165625bedde85e25f1eb988f0da8ca1>`_
- Merge pull request #28 from hartwork/issue_25 `8c77f6d93 <https://github.com/ralphbean/ansi2html/commit/8c77f6d93754c03fc256754de73b8b2bf1d6c08c>`_
- Fix italic to be font-style (rather than font-weight) `47b533b6d <https://github.com/ralphbean/ansi2html/commit/47b533b6de62ebe97d32322eaa3a5dcec735a077>`_
- Add inv* CSS classes `408808197 <https://github.com/ralphbean/ansi2html/commit/408808197e9b33aa55210b5f03940267b3e01c83>`_
- Handle state in code, not in HTML; support more ANSI codes `fce66a6a9 <https://github.com/ralphbean/ansi2html/commit/fce66a6a905fb6aa006cfa1f6ad4716ebb46e63b>`_
- Adapt tests to new approach to state `49046c620 <https://github.com/ralphbean/ansi2html/commit/49046c620079d3a325753081ba99b1deb0c8287a>`_
- Add CSS classes for lighter font style (2), blinking (5/6), hidden text (8) `e488daca3 <https://github.com/ralphbean/ansi2html/commit/e488daca38176c9cdba7318a958fc79bfb16f9cb>`_
- Save producing no-op span tags `340620f88 <https://github.com/ralphbean/ansi2html/commit/340620f88b66a686c16f155465f172321fe39cff>`_
- Test ANSI codes that just turned supported `f4774bcf0 <https://github.com/ralphbean/ansi2html/commit/f4774bcf0005175bc00f282f73365fa59b6f47fb>`_
- Make code testing pairs of files re-usable `f95ca305d <https://github.com/ralphbean/ansi2html/commit/f95ca305dba5951c25178fc12fb0e206120aa1b4>`_
- Add testcase for output from "eix -I svn -F" `e3f593671 <https://github.com/ralphbean/ansi2html/commit/e3f59367174fb9ed4df2d19ed012bae45f0ce2ce>`_
- Merge pull request #31 from hartwork/font-style-italic `a25950fe6 <https://github.com/ralphbean/ansi2html/commit/a25950fe6f0bdd12c92cbbd2109655bfd1cc5a36>`_
- Tweak for py3 support. `9766508e1 <https://github.com/ralphbean/ansi2html/commit/9766508e16007fdcd764ba52c79af798d8d816fd>`_
- Add py3.3 to travis config. `ceef1eb8e <https://github.com/ralphbean/ansi2html/commit/ceef1eb8e83a58fe895f67185f4242b8e49f7b7c>`_
- Merge branch 'stateful' into develop `29868b6ec <https://github.com/ralphbean/ansi2html/commit/29868b6ec1e742a23e3b60db17f187ce75bb3d57>`_
- 0.10.0 `b5c65d3a4 <https://github.com/ralphbean/ansi2html/commit/b5c65d3a4fa666aa397409900677c9c115625be7>`_
- Add missing license headers `44e5e52fa <https://github.com/ralphbean/ansi2html/commit/44e5e52faf6ea1eef57b8a3b1173f6794683dd4d>`_
- Fix README example to not produce unwanted spaces (issue 26) `cc6a0dbfa <https://github.com/ralphbean/ansi2html/commit/cc6a0dbfa2a86a827f8f737b0b610cbcb9afe282>`_
- Add --version parameter, control version in version.py `0b2006095 <https://github.com/ralphbean/ansi2html/commit/0b2006095e4b56896773fdaa4fb6b5526ecbde58>`_
- Improve --help output `26d297807 <https://github.com/ralphbean/ansi2html/commit/26d2978072f2f13836219d4999ff6b7d12ed031a>`_
- Add and integrate man page `2ec363007 <https://github.com/ralphbean/ansi2html/commit/2ec363007f49b91275d146414313783ba4d5ab61>`_
- No longer process line-by-line (fixes --partial and --inline, issue 36) `e3e86f9f8 <https://github.com/ralphbean/ansi2html/commit/e3e86f9f874a4243ee66a88022e752c7ceaf338e>`_
- Test cross-line state (related to issue 36) `c3eb8b9c5 <https://github.com/ralphbean/ansi2html/commit/c3eb8b9c51828da2e94aff9f5f77a363bc841850>`_
- Fix approach to trailing newlines `95e75e4d3 <https://github.com/ralphbean/ansi2html/commit/95e75e4d3e844aa33fb89045953c5d4869b3dbd2>`_
- Merge pull request #37 from hartwork/fix-line-handling `0fb5443ca <https://github.com/ralphbean/ansi2html/commit/0fb5443ca094bed79a4e30964716b2c3f875cb96>`_
- Merge pull request #33 from hartwork/headers `12bfa3251 <https://github.com/ralphbean/ansi2html/commit/12bfa325141f7c7f7d7a9f65147d30a3082fc53b>`_
- Merge pull request #34 from hartwork/fix-readme-example `b1ed96e00 <https://github.com/ralphbean/ansi2html/commit/b1ed96e00d324f0a4557917c02f425266dd224c1>`_
- Merge pull request #35 from hartwork/manpage `ad608eb2b <https://github.com/ralphbean/ansi2html/commit/ad608eb2b26751e983ac9e31ae412698f45d4664>`_

0.9.4
-----

- Fix encoding issue. `64881f549 <https://github.com/ralphbean/ansi2html/commit/64881f549126f5c576df7b75e70e49633fe59337>`_
- Silence silly py2.7 test errors. `b5db644ff <https://github.com/ralphbean/ansi2html/commit/b5db644ffa29497bd16dc0f0adae7f0847603f2c>`_

0.9.3
-----

- Fix encoding issue. `64881f549 <https://github.com/ralphbean/ansi2html/commit/64881f549126f5c576df7b75e70e49633fe59337>`_
- Silence silly py2.7 test errors. `b5db644ff <https://github.com/ralphbean/ansi2html/commit/b5db644ffa29497bd16dc0f0adae7f0847603f2c>`_
- Fix little encoding issue. `8cfbe166c <https://github.com/ralphbean/ansi2html/commit/8cfbe166c5645e459ad0ff3c061634a2146c26b9>`_
- Add trove for py3.3. `683f672fa <https://github.com/ralphbean/ansi2html/commit/683f672fa6071cc7390b6c64858127fe0b1e2e77>`_
- Stop adding unwanted spaces (issue 26) `b5163a80f <https://github.com/ralphbean/ansi2html/commit/b5163a80feea7f6ba8879357524ccbe143e68281>`_
- Add test for issue 25 `6df79eb8b <https://github.com/ralphbean/ansi2html/commit/6df79eb8b95b2c36e7395bedcd13e0facb323434>`_
- Fix destructive reset marker handling (issue 25) `4db97b126 <https://github.com/ralphbean/ansi2html/commit/4db97b126c600d30a922ab5899faa8879f699739>`_
- Fix ANSI code decoding (issue 25) `f277f8f3c <https://github.com/ralphbean/ansi2html/commit/f277f8f3c4eaa1256c5df66238583b5a69882456>`_
- Fix writing to sys.stdout.buffer `7a3267d53 <https://github.com/ralphbean/ansi2html/commit/7a3267d53a2ea61a0af6021faedf154ba89b2f87>`_
- Add convenience Makefile `8d3f3e055 <https://github.com/ralphbean/ansi2html/commit/8d3f3e055e679bf723d6a846fbff2c95a7224b9a>`_
- Merge pull request #30 from hartwork/makefile `156bc89da <https://github.com/ralphbean/ansi2html/commit/156bc89da97c7de19b2beb8e2de7bde2f2535a20>`_
- Merge pull request #29 from hartwork/issue_29 `8495723ae <https://github.com/ralphbean/ansi2html/commit/8495723ae8e057248537a53f9e7e800547d6640e>`_
- Merge pull request #27 from hartwork/issue_26 `74d237c18 <https://github.com/ralphbean/ansi2html/commit/74d237c18165625bedde85e25f1eb988f0da8ca1>`_
- Merge pull request #28 from hartwork/issue_25 `8c77f6d93 <https://github.com/ralphbean/ansi2html/commit/8c77f6d93754c03fc256754de73b8b2bf1d6c08c>`_
- Fix italic to be font-style (rather than font-weight) `47b533b6d <https://github.com/ralphbean/ansi2html/commit/47b533b6de62ebe97d32322eaa3a5dcec735a077>`_
- Add inv* CSS classes `408808197 <https://github.com/ralphbean/ansi2html/commit/408808197e9b33aa55210b5f03940267b3e01c83>`_
- Handle state in code, not in HTML; support more ANSI codes `fce66a6a9 <https://github.com/ralphbean/ansi2html/commit/fce66a6a905fb6aa006cfa1f6ad4716ebb46e63b>`_
- Adapt tests to new approach to state `49046c620 <https://github.com/ralphbean/ansi2html/commit/49046c620079d3a325753081ba99b1deb0c8287a>`_
- Add CSS classes for lighter font style (2), blinking (5/6), hidden text (8) `e488daca3 <https://github.com/ralphbean/ansi2html/commit/e488daca38176c9cdba7318a958fc79bfb16f9cb>`_
- Save producing no-op span tags `340620f88 <https://github.com/ralphbean/ansi2html/commit/340620f88b66a686c16f155465f172321fe39cff>`_
- Test ANSI codes that just turned supported `f4774bcf0 <https://github.com/ralphbean/ansi2html/commit/f4774bcf0005175bc00f282f73365fa59b6f47fb>`_
- Make code testing pairs of files re-usable `f95ca305d <https://github.com/ralphbean/ansi2html/commit/f95ca305dba5951c25178fc12fb0e206120aa1b4>`_
- Add testcase for output from "eix -I svn -F" `e3f593671 <https://github.com/ralphbean/ansi2html/commit/e3f59367174fb9ed4df2d19ed012bae45f0ce2ce>`_
- Merge pull request #31 from hartwork/font-style-italic `a25950fe6 <https://github.com/ralphbean/ansi2html/commit/a25950fe6f0bdd12c92cbbd2109655bfd1cc5a36>`_
- Tweak for py3 support. `9766508e1 <https://github.com/ralphbean/ansi2html/commit/9766508e16007fdcd764ba52c79af798d8d816fd>`_
- Add py3.3 to travis config. `ceef1eb8e <https://github.com/ralphbean/ansi2html/commit/ceef1eb8e83a58fe895f67185f4242b8e49f7b7c>`_
- Merge branch 'stateful' into develop `29868b6ec <https://github.com/ralphbean/ansi2html/commit/29868b6ec1e742a23e3b60db17f187ce75bb3d57>`_
